package edu.orangecoastcollege.cs272.btomita.ic03;
import java.util.*;

public class CatDemo
{
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        //Declare ArrayList as List but instantiate new ArrayList to facilitate lambda expressions
        List<Cat> cats = new ArrayList<>();
        Cat meowth = new Cat("Meowth", "Persian", 21);
        cats.add(meowth);
        Cat grumpyCat = new Cat("Grumpy Cat", "Mixed", 5);
        cats.add(grumpyCat);
        cats.add(new Cat("Grumpy Cat", "Mixed", 7));
        cats.add(new Cat("Garfield", "Ginger Tabby", 39));
        
        System.out.println("~~Unsorted List~~");
        for(Cat singleCat : cats)
        {
            System.out.println(singleCat);
        }
        
        System.out.println("~~Sorted List~~");
        Collections.sort(cats);
        for(Cat singleCat : cats)
        {
            System.out.println(singleCat);
        }
    }

}
