package edu.orangecoastcollege.cs272.ic09;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Java2PeopleFX extends Application {

	TextField nameTF = new TextField();
	Button addBtn = new Button("Add Person");

	@Override
	public void start(Stage primaryStage) throws Exception {

		GridPane pane = new GridPane();
		pane.add(new Label("Names:"), 0, 0);		
		HBox box = new HBox();
		box.getChildren().add(nameTF);
		box.getChildren().add(addBtn);
		box.setSpacing(25.0);
		pane.add(box, 0, 2);		
		
		Scene scene = new Scene(pane);			
		primaryStage.setTitle("Java 2 People");
		primaryStage.setScene(scene);
		primaryStage.show();
	}	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Application.launch(args);
	}
	
}
